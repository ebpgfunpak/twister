#!/bin/bash

#    If you have a local initialization script, put it here:
#    . /home/pg/jobs/wrapper.ini

# v3.0
                  # twister.sh     Align to marks rotated at up to 45 degrees,
                  #                by rotating the pattern before printing.
                  #                The pattern is rotated by 'flatten', then
                  #                converted to gpf with 'freebeam'.
                  #                This is a single alignment to one set of 
                  #                four marks. It seems unlikely that you will
                  #                need both global and local alignment, since
                  #                this program is for small substrates that are
                  #                difficult to align on-axis, and for people
                  #                who are too dopey to use larger substrates.

                  # requires:      freebeam, rotate_extents, rotate_point
                  #                calculate_rotation, flatten (included in Freebeam)
                  #                cview, python3

                  # assumes:       You have three or four alignment marks at the 
                  #                corners of a pattern, and that the pattern is
                  #                not sensitive to rotation. On-axis gratings
                  #                and sigle-pass lines will not work well here.
                  #                We also assume that the pattern is fairly simple,
                  #                so that it can be converted to gpf quickly.
                  
                  # In this example the pattern file is twister.gds,
                  # the top cell is named "flat" and the layer is 5.
infile="twister" 
suffix="gds" 
topcell="flat"

outfile="$infile"
                  # dose, in uC/cm2
dose="1382"
                  # beam archive file - set it to "" if you've already loaded it
#beamfile="40na_300"
beamfile=""

                  # (optional) file of <layer> <datatype> <relative-dose>
dosefile=""
                  # layer format: "1,2,3"  use commas, no spaces
layer="5"
                  # beam step size in nm
bss=10
                  # block (field) size in microns
                  # must be a multiple of bss.
                  # Maximum is 1000um, but you should not exeed 700um
                  # unless you have a good reason.
xblock=1000
yblock=1000
                  # The subfield size will be set automatically,
                  # unless you set xsub & ysub to nonzero values here. 
                  # Normally, you should set xsub and ysub to zero.
                  # The subfield size (um) must be a multiple of the bss.
xsub=0
ysub=0
                  # lower-left and upper-right bounds of the pattern.
                  # These are coordinates, in um, from your CAD file.
                  # THESE ARE NOT THE MARK LOCATIONS they are the PATTERN BOUNDS.
                  # The average of these is the chip center.
                  # DO NOT enter zeros because this would create 
                  # an unknown chip center.

                  # These extents must include the entire pattern.
                  # If you want to crop out part of the pattern
                  # then do it by hand in a CAD program- not here.
llx=-22000
lly=-22000        # center 5000,5000
urx=32000
ury=32000

                  # cropping window - set to zero 
crllx=0           # cropping is not allowed in twister
crlly=0           # because Freebeam does not understand
crurx=0           # a rotated cropping window.
crury=0           # If you need to crop, then do it manually
                  # by using 'flatten' and then 'layout'. 


found_marks_already="yes"     # yes => ul, ur, ll, lr have been found and saved
                              # no  => use mark detection to find them automatically
                              #        by first moving to 'corner' = upper left
                              #        then moving dx, dy to find the others

                  # If you use only THREE MARKS be sure to erase the unused symbol
                  # for example, "unset lr" and then put # on the elr= line below.

dx=9.38mm         # center-to-center distance between marks horizontally
dy=8.38mm         # and vertically - not used if found_marks_already = no

                  # Should we realign to the marks even if we found them already?
                  # Yes. Sometimes there are weird shifts after calibration, so
                  # you really do need to realign. Set realign_marks to "yes".
realign_marks="yes"

unset ell elr eur eul

if [[ found_marks_already == "no" ]]; then
    unset ll lr ul ur
fi

                  # Expected alignment mark positions. 
                  # These are vectors from chip center to each alignment mark,
                  # just like in Cjob. If you are clever, you will put
                  # the pattern ('chip') center at 0,0 so that the
                  # mark positions can be read directly from the CAD program.
                  #
                  # You can use three or four marks. Units are microns.
                  # DO NOT PUT SPACES IN THE COORDINATES. DO NOT USE MILLIMETERS.

ell="-9690,-8690"   # expected lower-left, um       -4690,-3690

elr="-310,-8690"    # expected lower-right, um     4690,-3690

eur="-310,-310"     # expected upper-right, um     4690,4690

eul="-9690,-310"    # expected upper-left, um       -4690,4690



mark_type="p10"

holder=3  

 
#----------------- END OF USER-DEFINED PARAMETERS ---------------------------------------------

function check_mark()     # args:   description, position
    {                     # return: mark position
    echo
    echo "Check $1..."
    pg move pos $2
    semon
    echo
    echo "Move around with the SEM window."
    echo "Press [a] to realign the mark with mvm,"
    read -p "or press [enter] to continue. " ans
    if [ "$ans" == "a" ]; then
	mvm 0,0 --rel $mark_type
	if [[ ! `pg get error` =~ "NORMAL" ]]; then
	    echo
	    echo "Alignment failed. Abort."
	    echo
	    exit
	fi
    fi
    semoff
    ret=`pg get tab`
    } 


# shift the pattern center to 0,0 before rotation.
# rotation will happen inside freebeam

cx=`python3 -c "print( -($llx + $urx)/2.0 )"`    
cy=`python3 -c "print( -($lly + $ury)/2.0 )"`    
abscx=`python3 -c "print( abs($llx + $urx)/2.0 )"`    
abscy=`python3 -c "print( abs($lly + $ury)/2.0 )"`    


if [ $abscx == "0.0" ] && [ $abscy == "0.0" ]; then
    cp $infile.$suffix tmp_flat.gds
else
    flatten $infile.$suffix $topcell -yesbox -nodump -silent -layer -1 0 tmp_flat.gds $cx $cy
    topcell="flat"
    llx=`python3 -c "print( $llx + $cx )"`
    lly=`python3 -c "print( $lly + $cy )"`
    urx=`python3 -c "print( $urx + $cx )"`
    ury=`python3 -c "print( $ury + $cy )"`
    echo
    echo "$infile.$suffix has been shifted by $cx $cy and written to tmp_flat.gds"
    echo "new extents: $llx $lly  to  $urx $ury"
    echo
fi

infile="tmp_flat"


pg map subs wafer delete
pg map subs chip  delete

pg sel holder $holder

                  # Now we collect the OBSERVED locations of the marks.
                  # One way to collect these coordinates is for you to move to
                  # each mark manually, then use "mvm 0,0 --rel p10" then "sp ll" etc.
                  # In that case, set found_marks_already="yes" above.

                  # Another way to collect these coordinates is shown here-
                  # Suppose that you have found the upper-left mark, and have given 
                  # that location a name, eg "sp corner". 

                  # Here we move to 'corner' with mvsp, measure its location with mvm,
                  # then move to the other marks and collect their positions also.
                  # This works if the rotation is not too extreme.
                  # Note that 'sp' does not work in a script, so we use 'pg get tab' instead.


if [[ $found_marks_already == "yes" ]]; then
    echo
    echo "You found the marks already and saved them as ul ur ll lr."
    echo
    mul=$ul
    mur=$ur
    mlr=$lr
    mll=$ll
fi

if [[ $found_marks_already == "no" ]]; then

    echo
    echo -n "Aligning to upper-left  mark... "
    pg move pos $corner                           # mvsp corner
    mvm 0,0 --rel $mark_type

    if [[ ! `pg get error` =~ "NORMAL" ]]; then
        echo
        echo "Cannot find upper-left mark. Abort."
        echo
        exit
    else
        echo "ok"
    fi

    mul=`pg get tab`

    echo -n "Aligning to lower-left  mark... "
    pg move pos --rel 0,-$dy                      # mvrl
    mvm 0,0 --rel $mark_type

    if [[ ! `pg get error` =~ "NORMAL" ]]; then
        echo
        echo "Cannot find lower-left mark. Abort."
        echo
        exit
    else
        echo "ok"
    fi

    mll=`pg get tab`

    echo -n "Aligning to lower-right mark... "
    pg move pos --rel $dx,0                      # mvrl
    mvm 0,0 --rel $mark_type

    if [[ ! `pg get error` =~ "NORMAL" ]]; then
        echo
        echo "Cannot find lower-right mark. Abort."
        echo
        exit
    else
        echo "ok"
    fi

    mlr=`pg get tab`

    echo -n "Aligning to upper-right mark... "
    pg mov pos --rel 0,$dy                      # mvrl
    mvm 0,0 --rel $mark_type

    if [[ ! `pg get error` =~ "NORMAL" ]]; then
        echo
        echo "Cannot find upper-right mark. Abort."
        echo
        exit
    else
        echo "ok"
    fi

    mur=`pg get tab`

    echo
    echo "Alignment complete."
    echo
        
fi           # if not found_marks_already

#---------------------------------------------------------------

                  # calculate the scale and rotation, then
                  # abort if these numbers are crazy.
                  # Expected and observed coordinates must appear
                  # in the same order. 


angle=`calculate_rotation $eul $ell $elr $eur $mul $mll $mlr $mur`

if [[ $angle =~ "ERROR" ]]; then
    echo -e $angle
    exit
fi

echo
echo "Rotation: $angle degrees"
echo


                  # Now rotate the chip extents and the expected mark locations.
                  # You might ask "why not use the observed mark locations as
                  # the expected locations?" Because this would not allow the 
                  # system to correct for pattern scaling. 

rm -f rotate_extents.dat
rotate_extents $bss $llx $lly $urx $ury $angle
read llx lly urx ury cx cy < rotate_extents.dat

                  # Rotate the expected mark locations and also shift them
                  # so we have vectors relative to the pattern center cx,cy


if [ ! $ul == '' ]; then eul=`rotate_point $eul $angle 0.0 0.0` ; fi
if [ ! $ll == '' ]; then ell=`rotate_point $ell $angle 0.0 0.0` ; fi
if [ ! $ur == '' ]; then eur=`rotate_point $eur $angle 0.0 0.0` ; fi
if [ ! $lr == '' ]; then elr=`rotate_point $elr $angle 0.0 0.0` ; fi
 

                  
                  # LSB is always 1 nm = 0.001um 
                  # unless you are doing something strange
lsb=1
                  # voltage in kV
voltage=100

split="yes"       # split input file for parallel processing
purge="yes"       # delete scratch files after use  
polygons="no"     # 'no' for GPG, 'yes' for UPG pattern generator with Firebird

                  # Pattern conversion to gpf. Freebeam requires the parameters
                  # llx, lly, urx, ury, infile, suffix, topcell, dosefile, layer,
                  # cr*, lsb, voltage, split, purge, bss, xblock, yblock, xsub, ysub, 
                  # and angle.

rm -f $outfile.gpf

. /home/pg/bin/freebeam/freebeam.sh -y    # PATTERN CONVERSION !!!!!!!!!!!!!!!!

echo
echo "Rotation: $angle degrees"
echo
 
if [ -f fullstop.txt ]; then exit ; fi

if [ ! -f $outfile.gpf ]; then
    echo
    echo "Pattern conversion failure. Well that sucks."
    echo "Please report this bug. Your help will be appreciated."
    echo "Abort."
    echo
    exit
fi

echo "Check pattern, then close cview to continue (or ^C to abort)"
echo

cview $outfile.gpf 

rm tmp_flat.gds 

echo
echo "Calibration..."
echo


if [ "$beamfile" != "" ]; then pg arc rest beam $beamfile ; fi

pg sel pattern $outfile.gpf
pg set resist $dose
pg adj ebpg

if [[ `pg get error` =~ "ENG_E" ]]; then
    echo
    echo "Calibration failure."
    echo "Try using a lower current and a smaller block size."
    echo "Abort."
    echo
    exit
fi

pg adj freq

if [[ `pg get error` =~ "ENG_E_FRQ" ]]; then
    echo
    echo "Frequency out of range."
    echo "The dose is too low, or the current is too high,"
    echo "or the beam step size is too small. Exposure aborted."
    echo
    exit
fi

echo
echo "Sometimes we get a shift after calibration. "
echo "This also happens with cjob, but no one knows why."
echo "Therefore you should check the mark locations."
echo "If the marks are far from the center of each view,"
echo "then you can use the SEM window to center them,"
echo "and you can rescan the mark if it is wrong."
echo

check_mark "upper-left"  $mul  
mul=$ret
check_mark "upper-right" $mur
mur=$ret
check_mark "lower-right" $mlr
mlr=$ret
check_mark "lower-left"  $mll
mll=$ret


if [[ $realign_marks == "yes" ]]; then
    echo
    echo "Realign to minimize drift..."
    echo

    if [ ! $mul == '' ]; then
        echo
        echo -n "Aligning to upper-left  mark... "
        pg mov pos $mul
        mvm 0,0 --rel $mark_type

        if [[ ! `pg get error` =~ "NORMAL" ]]; then
            echo
            echo "Cannot find upper-left mark. Abort."
            echo
            exit
        else
            echo "ok"
        fi

        mul=`pg get tab`
    fi

    if [ ! $mll == '' ]; then
        echo -n "Aligning to lower-left  mark... "
        pg mov pos $mll
        mvm 0,0 --rel $mark_type

        if [[ ! `pg get error` =~ "NORMAL" ]]; then
            echo
            echo "Cannot find lower-left mark. Abort."
            echo
            exit
        else
            echo "ok"
        fi

        mll=`pg get tab`
    fi

    if [ ! $mlr == '' ]; then
        echo -n "Aligning to lower-right mark... "
        pg mov pos $mlr
        mvm 0,0 --rel $mark_type

        if [[ ! `pg get error` =~ "NORMAL" ]]; then
            echo
            echo "Cannot find lower-right mark. Abort."
            echo
            exit
        else
            echo "ok"
        fi

        mlr=`pg get tab`
    fi

    if [ ! $mur == '' ]; then
        echo -n "Aligning to upper-right mark... "
        pg mov pos $mur
        mvm 0,0 --rel $mark_type

        if [[ ! `pg get error` =~ "NORMAL" ]]; then
            echo
            echo "Cannot find upper-right mark. Abort."
            echo
            exit
        else
            echo "ok"
        fi

        mur=`pg get tab`
    fi

    echo
    echo "Alignment complete."
    echo
fi        # end if realign_marks


if [ ! $eul == '' ]; then pg table eul $eul ; fi
if [ ! $ell == '' ]; then pg table ell $ell ; fi
if [ ! $elr == '' ]; then pg table elr $elr ; fi
if [ ! $eur == '' ]; then pg table eur $eur ; fi
if [ ! $mul == '' ]; then pg table mul $mul ; fi
if [ ! $mll == '' ]; then pg table mll $mll ; fi
if [ ! $mlr == '' ]; then pg table mlr $mlr ; fi
if [ ! $mur == '' ]; then pg table mur $mur ; fi

echo
echo "*****************************************"
echo "eul = $eul"
echo "ell = $ell"
echo "eur = $eur"
echo "elr = $elr"
echo "*****************************************"
echo


if [ ! $eul == '' ] && [ ! $ell == '' ] && [ ! $elr == '' ] && [ ! $eur == '' ];
    then
    pg calc subs wafer eul,mul ell,mll elr,mlr eur,mur

elif [ ! $ell == '' ] && [ ! $elr == '' ] && [ ! $eur == '' ];
    then
    pg calc subs wafer ell,mll elr,mlr eur,mur

elif  [ ! $eul == '' ] && [ ! $elr == '' ] && [ ! $eur == '' ];
    then
    pg calc subs wafer eul,mul elr,mlr eur,mur

elif  [ ! $eul == '' ] && [ ! $ell == '' ] && [ ! $eur == '' ];
    then
    pg calc subs wafer eul,mul ell,mll eur,mur 

elif  [ ! $eul == '' ] && [ ! $ell == '' ] && [ ! $elr == '' ];
    then
    pg calc subs wafer eul,mul ell,mll elr,mlr

else
    echo
    echo "ERROR: you must use three or four alignment marks"
    echo
    exit
fi

pg sel map subs wafer

status=`pg get error`

if [[ $status =~ "ENG_E_" ]]; then
    echo
    echo "ALIGNMENT ERROR--------------------------"
    echo
    echo $status
    pg map subs wafer delete
    exit
fi


pg expose pattern 0,0

pg map subs wafer delete
pg map subs chip  delete

echo
echo "Done."
echo



rm -f /home/pg/pid.txt
